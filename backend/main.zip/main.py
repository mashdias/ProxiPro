from fastapi import FastAPI
from contextlib import asynccontextmanager
from database import init_db
from routers import auth, vendors

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Connect to DB and ensure indexes
    await init_db()
    yield
    # Shutdown: Add any cleanup logic here
    print("Shutting down application...")

app = FastAPI(
    title="Micro-Business Service Marketplace",
    description="FastAPI Backend for the vendor marketplace with geospatial search.",
    version="1.0.0",
    lifespan=lifespan
)

# Include routers
app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
app.include_router(vendors.router, prefix="/api/vendors", tags=["Vendors"])

@app.get("/api/health", tags=["Health"])
async def health_check():
    return {"status": "ok", "message": "FastAPI is running and ready to serve!"}
